from django.apps import AppConfig


class SocializeConfig(AppConfig):
    name = 'socialize'
